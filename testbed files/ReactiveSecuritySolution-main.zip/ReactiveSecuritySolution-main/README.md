# ReactiveSecuritySolution
project  path 
	/home/marcelo/Documents/ReactiveSecuritySolution/

1. Run Topology
	python2 ips/topo.py

2. flow collector
	The flow collector gathers statistics from the edge switches. 
	To configure:
		In FlowCollector.java
			device = "s101-eth1": the SW that the flowcollector is connected to.
			String jsonFlow1 =  (newFlow.getValue()).SelectedCICDDoS2019FlowBasedFeatures(); depending of the analyzed attacks
			"http://192.168.0.101:9001/predict" the direction of the IDS server
			SelectiveFlowSampling() the flow filter parameters
	To run:
		compile: in the flowCollector/ path
		//linux:
		$ sudo bash
		$ gradle execute

3. run ids
	- high-volume
	python2 ids/high-volume/lstm/lstm2019_server_main_v2.py
	- slow-rate
	python2 /ids/slow-rate/lstm/lstm2017server_main_v1.py

